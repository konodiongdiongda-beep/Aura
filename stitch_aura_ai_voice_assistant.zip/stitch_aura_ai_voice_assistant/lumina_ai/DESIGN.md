---
name: Lumina AI
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#464554'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#767586'
  outline-variant: '#c7c4d7'
  surface-tint: '#494bd6'
  primary: '#4648d4'
  on-primary: '#ffffff'
  primary-container: '#6063ee'
  on-primary-container: '#fffbff'
  inverse-primary: '#c0c1ff'
  secondary: '#0058be'
  on-secondary: '#ffffff'
  secondary-container: '#2170e4'
  on-secondary-container: '#fefcff'
  tertiary: '#575c65'
  on-tertiary: '#ffffff'
  tertiary-container: '#70757e'
  on-tertiary-container: '#fdfcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#dee2ed'
  tertiary-fixed-dim: '#c2c6d1'
  on-tertiary-fixed: '#171c23'
  on-tertiary-fixed-variant: '#424750'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  ai-response:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '450'
    lineHeight: 28px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 40px
---

## Brand & Style
The design system is built to bridge the gap between advanced artificial intelligence and human-centric warmth. It targets a modern, tech-savvy audience that values efficiency but seeks a tool that feels approachable rather than sterile. 

The style is a hybrid of **Minimalism** and **Subtle Glassmorphism**. It prioritizes heavy whitespace and a restricted palette to reduce cognitive load during complex AI interactions. Visual interest is generated through "living" elements: frosted glass surfaces that hint at depth and soft, ethereal glows that signify the AI's presence. The interface should feel like a lightweight layer floating over the user's workflow, evoking a sense of calm, intelligence, and future-readiness.

## Colors
The palette centers on "Soft Indigo" as the primary driver for action and identity, supported by "AI Blue" for secondary accents and state indications. 

- **Primary (Soft Indigo):** Used for main action buttons and active states.
- **Secondary (AI Blue):** Used for links, information callouts, and subtle highlights.
- **Surface & Background:** A sophisticated mix of soft whites (#FFFFFF) and very light grays (#F8FAFC) to create a tiered visual hierarchy.
- **The Glow:** A semi-transparent gradient utilizing the primary indigo at 20% opacity, used specifically for the AI's "listening" and "thinking" states to create a tech-forward aura.

## Typography
This design system utilizes **Inter** exclusively to ensure a systematic, utilitarian, and highly readable experience. 

- **Hierarchy:** Distinct contrast between bold headlines and airy body text. 
- **AI Presence:** AI-generated responses use the `ai-response` token, which features a slightly larger font size and custom weight (450) to distinguish the "voice" of the assistant from user-generated content or system UI.
- **Readability:** Tight letter-spacing on large headings provides a premium, modern feel, while standard spacing on body text ensures accessibility during long reading sessions.

## Layout & Spacing
The layout follows a **Fluid Grid** model with a focus on mobile-first interaction. 

- **Rhythm:** An 8px linear scale governs all padding and margins to maintain a strict vertical rhythm.
- **Mobile:** Elements are contained within a safe area with 20px side margins. 
- **Chat Flow:** The AI conversation uses a centered max-width container (800px) on larger screens to prevent line lengths from becoming unreadable, while remaining fluid on mobile devices.
- **Dynamic Padding:** Cards and chat bubbles use increased internal padding (`lg` or 24px) to emphasize the lightweight, "breathable" nature of the interface.

## Elevation & Depth
Depth is articulated through **Glassmorphism** and **Ambient Shadows**.

1.  **The Base Layer:** Solid background colors (#F8FAFC).
2.  **The Content Layer:** Standard white surfaces with "Soft" shadows (0px 4px 20px rgba(0,0,0,0.05)).
3.  **The Interactive Layer (Glass):** Floating headers, navigation bars, and AI input areas use a backdrop-blur (12px to 20px) with a 70% opaque white background and a 1px inner border (white at 40% opacity) to simulate a physical edge.
4.  **The AI Glow:** Elements associated with active AI processing use an outer "bloom" effect—a soft, multi-layered shadow tinted with the Primary Indigo color to simulate light emission.

## Shapes
The shape language is consistently **Rounded**, avoiding sharp edges to maintain the "warm" brand personality.

- **Buttons & Inputs:** Utilize `rounded-lg` (16px) for a soft, tactile feel.
- **Chat Bubbles:** User bubbles feature a higher corner radius on three sides with a sharper "tail" corner to indicate direction. AI bubbles remain perfectly uniform and rounded.
- **Modals & Cards:** Use `rounded-xl` (24px) to create a distinct enclosure that feels friendly and modern.

## Components
- **AI Voice Interface:** A circular or pill-shaped trigger with a 24px backdrop blur. When active, it emits a breathing "glow" animation using a primary-colored radial gradient.
- **Buttons:** Primary buttons are solid Soft Indigo with white text. Secondary buttons are "Ghost" style with a 1px AI Blue border and transparent background.
- **Input Fields:** Search and message inputs use a 12px backdrop blur and a subtle 1px border. The cursor or focus state should trigger a soft glow behind the input container.
- **Chips/Suggestions:** Small, pill-shaped buttons with `tertiary_color` backgrounds and `primary_color` text. They appear to float slightly above the surface.
- **Message Cards:** AI-generated content (like weather, images, or data) is housed in white cards with `rounded-xl` corners and the standard ambient shadow.
- **Lists:** Clean rows separated by thin, low-opacity lines (1px #E2E8F0), with generous 16px vertical padding.